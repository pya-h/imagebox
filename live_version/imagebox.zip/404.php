<!DOCTYPE html>
<html lang="en">
<head>
    <title>Image Drop Box</title>
    <link rel="stylesheet" href="./css/styles.css" />
</head>
<body>
    <?php
        require_once __DIR__ . '/common/nav.php';
    ?>
    <h1 style="font-size: 50px">Not Found</h1>
</body>
</html>
